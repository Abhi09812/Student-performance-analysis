package com.klef.jfsd.springboot.service;


import com.klef.jfsd.springboot.model.Teacher;

public interface TeacherService  
{ 
	
 public Teacher checkteacherlogin(String username, String password);




 
 
}