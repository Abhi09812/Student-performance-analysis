package com.klef.jfsd.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SdpprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SdpprojectApplication.class, args);
		System.out.println("This is our Project of SDP....!!");

	}

}
